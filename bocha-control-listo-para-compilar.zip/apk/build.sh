#!/bin/bash
# BOCHA Control — compila el APK nativo sin Gradle.
# Requiere: JDK 17 (/tmp/jdk), Android SDK (/tmp/sdk) y dist/ ya construido.
set -euo pipefail

export JAVA_HOME="${JAVA_HOME:-/tmp/jdk}"
export PATH="$JAVA_HOME/bin:$PATH"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/tmp/sdk}}"
BT="$SDK/build-tools/34.0.0"
ANDROID_JAR="$SDK/platforms/android-34/android.jar"
PROJ="$(cd "$(dirname "$0")/.." && pwd)"
WORK=/tmp/bocha-build

echo "== preparando =="
rm -rf "$WORK"
mkdir -p "$WORK"/{gen,classes,dex,res/mipmap-xxxhdpi,res/mipmap-xxhdpi,res/mipmap-xhdpi,res/mipmap-hdpi,res/mipmap-mdpi,assets/app}

cp "$PROJ/dist/index.html" "$WORK/assets/app/index.html"
for d in xxxhdpi xxhdpi xhdpi hdpi mdpi; do
  cp "$PROJ/public/icons/icon-512.png" "$WORK/res/mipmap-$d/ic_launcher.png"
done

echo "== aapt2 compile =="
"$BT/aapt2" compile --dir "$WORK/res" -o "$WORK/res.zip"

echo "== aapt2 link =="
"$BT/aapt2" link -o "$WORK/unsigned.apk" \
  --manifest "$PROJ/apk/AndroidManifest.xml" \
  -I "$ANDROID_JAR" \
  --java "$WORK/gen" \
  -A "$WORK/assets" \
  --min-sdk-version 24 --target-sdk-version 34 \
  "$WORK/res.zip"

echo "== javac =="
javac -encoding UTF-8 -cp "$ANDROID_JAR" \
  -d "$WORK/classes" \
  $(find "$WORK/gen" -name 'R.java') \
  "$PROJ/apk/src/com/bocha/control/MainActivity.java"

echo "== d8 (dex) =="
"$BT/d8" --min-api 24 --output "$WORK/dex" \
  $(find "$WORK/classes" -name '*.class')

echo "== empaquetando =="
cp "$WORK/unsigned.apk" "$WORK/merged.apk"
cd "$WORK/dex"
zip -0 -q "$WORK/merged.apk" classes.dex
cd -

echo "== zipalign =="
"$BT/zipalign" -p -f 4 "$WORK/merged.apk" "$WORK/aligned.apk"

echo "== firma =="
if [ ! -f "$PROJ/apk/bocha.jks" ]; then
  keytool -genkeypair -keystore "$PROJ/apk/bocha.jks" -alias bocha \
    -keyalg RSA -keysize 2048 -validity 10950 \
    -storepass bocha-control -keypass bocha-control \
    -dname "CN=Bocha Control, OU=Bocha, O=Bocha, C=ES" -storetype JKS
fi
"$BT/apksigner" sign \
  --ks "$PROJ/apk/bocha.jks" --ks-key-alias bocha \
  --ks-pass pass:bocha-control --key-pass pass:bocha-control \
  --min-sdk-version 24 --v1-signing-enabled true --v2-signing-enabled true \
  --out "$PROJ/public/bocha-control.apk" \
  "$WORK/aligned.apk"

echo "== verificación =="
"$BT/apksigner" verify --print-certs "$PROJ/public/bocha-control.apk" | head -4
ls -la "$PROJ/public/bocha-control.apk"
echo "APK_OK"
