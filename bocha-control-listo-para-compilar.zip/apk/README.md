# BOCHA Control — regenerar el APK

```bash
npm run build        # genera dist/index.html (single-file)
bash apk/build.sh    # compila + firma -> public/bocha-control.apk
npm run build        # re-empaqueta dist/ incluyendo el APK descargable
```

Requisitos: JDK 17 y Android SDK (platform `android-34` + `build-tools 34.0.0`)
en `/tmp/jdk` y `/tmp/sdk`. El script usa `aapt2`, `javac`, `d8`, `zipalign`
y `apksigner` directamente (sin Gradle).

La app completa vive empaquetada en `assets/app/index.html`; el WebView nativo
habilita `allowUniversalAccessFromFileURLs`, por lo que habla directamente con
el `web_server` del ESP8266 sin restricciones de CORS ni mixed-content.

Keystore de depuración: `apk/bocha.jks` (alias `bocha`, pass `bocha-control`).
