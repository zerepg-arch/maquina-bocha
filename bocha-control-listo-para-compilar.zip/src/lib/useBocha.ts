import { useCallback, useEffect, useRef, useState } from "react";
import { BochaClient, type Link, type NumKey } from "./esphome";
import { MotorEngine, type EngineConfig, type EngineSnapshot } from "./engine";

const CFG_KEY = "bocha.config.v1";
const DEFAULT_CFG: EngineConfig = {
  velocidad: 50,
  temporizador: 0,
  rampaSubida: 2,
  rampaBajada: 1,
};

const NUM_MAP: Record<keyof EngineConfig, NumKey> = {
  velocidad: "numVelocidad",
  temporizador: "numTemporizador",
  rampaSubida: "numRampaSubida",
  rampaBajada: "numRampaBajada",
};

function loadCfg(): EngineConfig {
  try {
    const raw = localStorage.getItem(CFG_KEY);
    if (raw) return { ...DEFAULT_CFG, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return { ...DEFAULT_CFG };
}

const INITIAL_SNAP: EngineSnapshot = {
  sentido: 0,
  sentidoSalida: 0,
  nivel: 0,
  estado: "Parado",
  timerLeftMs: null,
  activo: false,
};

const buzz = (ms: number | number[]) => {
  try {
    navigator.vibrate?.(ms);
  } catch {
    /* sin haptics */
  }
};

export interface BochaApi {
  host: string;
  link: Link;
  snap: EngineSnapshot;
  cfg: EngineConfig;
  estadoShown: string;
  giro: (dir: 1 | -1) => void;
  parar: () => void;
  setParam: (key: keyof EngineConfig, value: number, send?: boolean) => void;
  setHost: (host: string) => void;
  probe: () => Promise<Link>;
  syncFromDevice: () => Promise<void>;
}

export function useBocha(): BochaApi {
  const clientRef = useRef<BochaClient | null>(null);
  const engineRef = useRef<MotorEngine | null>(null);
  if (!clientRef.current) clientRef.current = new BochaClient();
  if (!engineRef.current) {
    engineRef.current = new MotorEngine(loadCfg());
    engineRef.current.start();
  }
  const client = clientRef.current;
  const engine = engineRef.current;

  const [link, setLink] = useState<Link>("probing");
  const [host, setHostState] = useState(client.host);
  const [snap, setSnap] = useState<EngineSnapshot>(INITIAL_SNAP);
  const [estadoReal, setEstadoReal] = useState<string | null>(null);
  const [cfg, setCfg] = useState<EngineConfig>({ ...engine.config });
  const debounce = useRef<Record<string, ReturnType<typeof setTimeout>>>({});
  const fails = useRef(0);

  useEffect(() => engine.subscribe(setSnap), [engine]);

  const syncFromDevice = useCallback(async () => {
    const keys = Object.keys(NUM_MAP) as (keyof EngineConfig)[];
    const vals = await Promise.all(keys.map((k) => client.getNumber(NUM_MAP[k])));
    setCfg((prev) => {
      const next = { ...prev };
      let changed = false;
      keys.forEach((k, i) => {
        const v = vals[i];
        if (v !== null && Number.isFinite(v) && Math.abs(v - next[k]) > 1e-6) {
          next[k] = v;
          changed = true;
        }
      });
      if (changed) {
        engine.setConfig(next);
        localStorage.setItem(CFG_KEY, JSON.stringify(next));
      }
      return changed ? next : prev;
    });
  }, [client, engine]);

  const probe = useCallback(async (): Promise<Link> => {
    setLink("probing");
    const res = await client.probe();
    setLink(res);
    fails.current = 0;
    if (res === "full") {
      const e = await client.getEstado();
      if (e) setEstadoReal(e);
      void syncFromDevice();
    } else if (res !== "opaque") {
      setEstadoReal(null);
    }
    return res;
  }, [client, syncFromDevice]);

  // sonda inicial + latido de reconexión
  useEffect(() => {
    void probe();
    const beat = setInterval(() => {
      if (document.hidden) return;
      if (client.link !== "full") void probe();
    }, 12000);
    return () => clearInterval(beat);
  }, [client, probe]);

  // polling de estado cuando el enlace es completo (APK / mismo origen)
  useEffect(() => {
    let n = 0;
    const t = setInterval(async () => {
      if (document.hidden || client.link !== "full") return;
      const e = await client.getEstado();
      if (e) {
        setEstadoReal(e);
        fails.current = 0;
      } else if (++fails.current >= 3) {
        setEstadoReal(null);
        setLink("offline");
        fails.current = 0;
      }
      if (++n % 6 === 0) void syncFromDevice();
    }, 1200);
    return () => clearInterval(t);
  }, [client, syncFromDevice]);

  // wake lock: mantiene la pantalla viva mientras la app está abierta
  useEffect(() => {
    let lock: { release?: () => Promise<void> } | null = null;
    const req = async () => {
      try {
        const wl = (
          navigator as unknown as {
            wakeLock?: { request: (t: string) => Promise<{ release?: () => Promise<void> }> };
          }
        ).wakeLock;
        lock = wl ? await wl.request("screen") : null;
      } catch {
        /* no disponible */
      }
    };
    void req();
    const onVis = () => {
      if (document.visibilityState === "visible") void req();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      void lock?.release?.();
    };
  }, []);

  const trackSend = useCallback((p: Promise<boolean>) => {
    void p.then((ok) => {
      if (!ok) setLink((l) => (l === "full" ? "offline" : l));
    });
  }, []);

  const giro = useCallback(
    (dir: 1 | -1) => {
      engine.giro(dir);
      buzz(14);
      if (client.link === "offline") {
        void probe();
      }
      trackSend(client.press(dir === 1 ? "btnDerecha" : "btnIzquierda"));
    },
    [client, engine, probe, trackSend],
  );

  const parar = useCallback(() => {
    engine.parar();
    buzz([20, 40, 20]);
    if (client.link === "offline") void probe();
    trackSend(client.press("btnParar"));
  }, [client, engine, probe, trackSend]);

  const setParam = useCallback(
    (key: keyof EngineConfig, value: number, send = true) => {
      setCfg((prev) => {
        const next = { ...prev, [key]: value };
        localStorage.setItem(CFG_KEY, JSON.stringify(next));
        return next;
      });
      engine.setConfig({ [key]: value });
      if (!send) return;
      clearTimeout(debounce.current[key]);
      debounce.current[key] = setTimeout(() => {
        if (client.link === "offline") void probe();
        trackSend(client.setNumber(NUM_MAP[key], value));
      }, 320);
    },
    [client, engine, probe, trackSend],
  );

  const setHost = useCallback(
    (h: string) => {
      client.setHost(h);
      setHostState(client.host);
      setEstadoReal(null);
      void probe();
    },
    [client, probe],
  );

  return {
    host,
    link,
    snap,
    cfg,
    estadoShown: link === "full" && estadoReal ? estadoReal : snap.estado,
    giro,
    parar,
    setParam,
    setHost,
    probe,
    syncFromDevice,
  };
}
