/**
 * Capa de red hacia el web_server de ESPHome (v3).
 *
 * Replica el algoritmo de object_id del firmware:
 *   object_id = por cada char del NOMBRE: to_sanitized_char(to_snake_case_char(c))
 *   - espacio -> '_' | mayúscula -> minúscula | resto [^-_0-9a-zA-Z] -> '_'
 * Como hay variantes según la versión de ESPHome (colapso de guiones, ids
 * explícitos, etc.), generamos una lista de candidatos y la resolvemos por
 * sonda cuando el modo de enlace lo permite.
 */

export type Link = "probing" | "full" | "opaque" | "offline";

const snake = (c: string) => (c === " " ? "_" : c >= "A" && c <= "Z" ? c.toLowerCase() : c);
const san = (c: string) => (/[-_0-9a-zA-Z]/.test(c) ? c : "_");

export function esphomeIds(name: string, extra: string[] = []): string[] {
  const modern = name
    .split("")
    .map((c) => san(snake(c)))
    .join("");
  const trimTrailing = modern.replace(/_+$/, "");
  const collapsed = modern.replace(/^_+|_+$/g, "").replace(/_+/g, "_");
  const out = [modern, trimTrailing, collapsed, ...extra].filter((s) => s.length > 0);
  return Array.from(new Set(out));
}

export type BtnKey = "btnParar" | "btnDerecha" | "btnIzquierda";
export type NumKey = "numVelocidad" | "numTemporizador" | "numRampaSubida" | "numRampaBajada";
export type EntityKey = BtnKey | NumKey | "txtEstado";

export const ENTITIES: Record<EntityKey, string[]> = {
  btnParar: esphomeIds("Parar"),
  btnDerecha: esphomeIds("Giro derecha"),
  btnIzquierda: esphomeIds("Giro izquierda"),
  numVelocidad: esphomeIds("Velocidad (%)", ["velocidad"]),
  numTemporizador: esphomeIds("Temporizador (minutos, 0 = sin limite)", ["temporizador"]),
  numRampaSubida: esphomeIds("Rampa de aceleracion (segundos, 0 = sin rampa)", ["rampa_subida"]),
  numRampaBajada: esphomeIds("Rampa de desaceleracion (segundos, 0 = sin rampa)", ["rampa_bajada"]),
  txtEstado: esphomeIds("Estado", ["estado_motor"]),
};

const HOST_KEY = "bocha.host";
const DEFAULT_HOST = "192.168.4.1";

export class BochaClient {
  host: string;
  link: Link = "probing";
  /** entidad resuelta -> id que respondió 200 (modo full) */
  private resolved = new Map<EntityKey, string>();

  constructor() {
    this.host = localStorage.getItem(HOST_KEY) || DEFAULT_HOST;
  }

  setHost(host: string) {
    const clean = host.trim().replace(/^https?:\/\//, "").replace(/\/+$/, "");
    this.host = clean || DEFAULT_HOST;
    this.resolved.clear();
    localStorage.setItem(HOST_KEY, this.host);
  }

  get base() {
    return `http://${this.host}`;
  }

  private signal(ms: number) {
    const c = new AbortController();
    setTimeout(() => c.abort(), ms);
    return c.signal;
  }

  /** Sonda el dispositivo: full (lectura+control), opaque (solo control) u offline */
  async probe(): Promise<Link> {
    this.link = "probing";
    // 1) lectura real del text_sensor -> implica respuestas legibles (APK / mismo origen)
    for (const id of ENTITIES.txtEstado) {
      try {
        const r = await fetch(`${this.base}/text_sensor/${id}`, { signal: this.signal(2600) });
        if (r.ok) {
          this.resolved.set("txtEstado", id);
          this.link = "full";
          return "full";
        }
      } catch {
        /* sin CORS o caído */
      }
    }
    // 2) reachable pero opaco (navegador con CORS): / responde aunque no podamos leer
    try {
      await fetch(`${this.base}/`, { mode: "no-cors", signal: this.signal(2600) });
      this.link = "opaque";
    } catch {
      this.link = "offline";
    }
    return this.link;
  }

  private async postAll(urls: string[]): Promise<boolean> {
    let ok = false;
    const jobs = urls.map(async (u) => {
      if (this.link === "full") {
        try {
          const r = await fetch(u, { method: "POST", signal: this.signal(2200) });
          if (r.ok) {
            ok = true;
            return true;
          }
        } catch {
          /* ignore */
        }
        return false;
      }
      try {
        await fetch(u, { method: "POST", mode: "no-cors", signal: this.signal(2200) });
        ok = true; // optimista: el comando al menos salió
        return true;
      } catch {
        return false;
      }
    });
    await Promise.all(jobs);
    if (!ok) this.link = "offline";
    return ok;
  }

  async press(key: BtnKey): Promise<boolean> {
    let ids = ENTITIES[key];
    const r = this.resolved.get(key);
    if (r) ids = [r];
    else if (this.link === "full") ids = ids.slice(0, 2); // acota la expansión
    const urls = ids.map((id) => `${this.base}/button/${id}/press`);
    const okAll = await this.tryResolve(key, ids, "button", "press");
    return okAll ?? (await this.postAll(urls));
  }

  async setNumber(key: NumKey, value: number): Promise<boolean> {
    let ids = ENTITIES[key];
    const r = this.resolved.get(key);
    if (r) ids = [r];
    else if (this.link === "full") ids = ids.slice(0, 2);
    const urls = ids.map((id) => `${this.base}/number/${id}/set?value=${encodeURIComponent(value)}`);
    const okAll = await this.tryResolve(key, ids, "number", `set?value=${encodeURIComponent(value)}`);
    return okAll ?? (await this.postAll(urls));
  }

  /** En modo full descubre qué candidato existe y lo fija. Devuelve null si no resolvió. */
  private async tryResolve(
    key: EntityKey,
    ids: string[],
    domain: "button" | "number",
    action: string,
  ): Promise<boolean | null> {
    if (this.link !== "full") return null;
    const known = this.resolved.get(key);
    if (known) {
      try {
        const r = await fetch(`${this.base}/${domain}/${known}/${action}`, {
          method: "POST",
          signal: this.signal(2200),
        });
        return r.ok;
      } catch {
        this.link = "offline";
        return false;
      }
    }
    let any = false;
    for (const id of ids) {
      try {
        const r = await fetch(`${this.base}/${domain}/${id}`, { signal: this.signal(2000) });
        if (r.ok) {
          this.resolved.set(key, id);
          await fetch(`${this.base}/${domain}/${id}/${action}`, {
            method: "POST",
            signal: this.signal(2200),
          });
          any = true;
        }
      } catch {
        /* sigue */
      }
    }
    return any || null;
  }

  async getEstado(): Promise<string | null> {
    const id = this.resolved.get("txtEstado");
    if (!id || this.link !== "full") return null;
    try {
      const r = await fetch(`${this.base}/text_sensor/${id}`, { signal: this.signal(2200) });
      if (!r.ok) return null;
      const j = await r.json();
      return String(j.state ?? j.value ?? "");
    } catch {
      return null;
    }
  }

  async getNumber(key: NumKey): Promise<number | null> {
    if (this.link !== "full") return null;
    const id = this.resolved.get(key);
    if (!id) {
      // resuelve con GET
      for (const cand of ENTITIES[key]) {
        try {
          const r = await fetch(`${this.base}/number/${cand}`, { signal: this.signal(2000) });
          if (r.ok) {
            this.resolved.set(key, cand);
            const j = await r.json();
            return typeof j.value === "number" ? j.value : parseFloat(j.state);
          }
        } catch {
          /* sigue */
        }
      }
      return null;
    }
    try {
      const r = await fetch(`${this.base}/number/${id}`, { signal: this.signal(2000) });
      if (!r.ok) return null;
      const j = await r.json();
      return typeof j.value === "number" ? j.value : parseFloat(j.state);
    } catch {
      return null;
    }
  }
}
