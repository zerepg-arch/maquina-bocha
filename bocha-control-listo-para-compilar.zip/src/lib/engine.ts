/**
 * Réplica exacta de la lógica del YAML (interval 50ms + script temporizador_giro
 * + lambda de rampas). El gauge de la app siempre refleja lo que hace el motor,
 * incluso cuando el dispositivo no permite lectura de estado (modo "a ciegas").
 */

export interface EngineConfig {
  velocidad: number; // 10..100 (%)
  temporizador: number; // minutos, 0 = sin límite
  rampaSubida: number; // segundos, 0 = sin rampa
  rampaBajada: number; // segundos, 0 = sin rampa
}

export interface EngineSnapshot {
  sentido: number; // -1 | 0 | 1 (orden dada)
  sentidoSalida: number; // -1 | 0 | 1 (giro efectivo tras rampas)
  nivel: number; // 0..1
  estado: string; // texto idéntico al text_sensor del ESP
  timerLeftMs: number | null; // cuenta atrás del auto-paro
  activo: boolean;
}

type Listener = (s: EngineSnapshot) => void;

export class MotorEngine {
  config: EngineConfig;
  private sentido = 0;
  private sentidoSalida = 0;
  private nivel = 0;
  private timerUntil: number | null = null;
  private handle: ReturnType<typeof setInterval> | null = null;
  private listeners = new Set<Listener>();
  private snapshot: EngineSnapshot;

  constructor(config: EngineConfig) {
    this.config = { ...config };
    this.snapshot = this.buildSnapshot("Parado");
  }

  start() {
    if (this.handle) return;
    this.handle = setInterval(() => this.tick(), 50);
  }

  destroy() {
    if (this.handle) clearInterval(this.handle);
    this.handle = null;
    this.listeners.clear();
  }

  subscribe(fn: Listener): () => void {
    this.listeners.add(fn);
    fn(this.snapshot);
    return () => this.listeners.delete(fn);
  }

  setConfig(patch: Partial<EngineConfig>) {
    this.config = { ...this.config, ...patch };
  }

  /** Botones "Giro derecha/izquierda" del YAML: sentido = ±1 y arranca temporizador_giro (mode: restart) */
  giro(dir: 1 | -1) {
    this.sentido = dir;
    this.timerUntil =
      this.config.temporizador > 0 ? performance.now() + this.config.temporizador * 60000 : null;
    this.tick();
    this.emit();
  }

  /** Botón "Parar" del YAML: script.stop + fuerza todo a cero al instante */
  parar() {
    this.sentido = 0;
    this.sentidoSalida = 0;
    this.nivel = 0;
    this.timerUntil = null;
    this.snapshot = this.buildSnapshot("Parado");
    this.emit();
  }

  private tick() {
    const now = performance.now();
    // script temporizador_giro: tras el delay -> sentido = 0
    if (this.timerUntil !== null && now >= this.timerUntil) {
      this.sentido = 0;
      this.timerUntil = null;
    }

    // --- port literal del lambda del YAML ---
    const dirDes = this.sentido;
    let dirSal = this.sentidoSalida;
    let nivel = this.nivel;

    if (dirSal === 0 && dirDes !== 0) dirSal = dirDes;

    let obj = dirDes === 0 ? 0 : this.config.velocidad / 100;
    if (dirDes !== 0 && dirDes !== dirSal) obj = 0;

    const tSub = this.config.rampaSubida;
    const tBaj = this.config.rampaBajada;
    const pasoSub = tSub > 0 ? 0.05 / tSub : 1;
    const pasoBaj = tBaj > 0 ? 0.05 / tBaj : 1;

    if (nivel < obj) {
      nivel += pasoSub;
      if (nivel > obj) nivel = obj;
    } else if (nivel > obj) {
      nivel -= pasoBaj;
      if (nivel < obj) nivel = obj;
    }

    if (nivel <= 0.0001) {
      nivel = 0;
      if (dirSal !== dirDes) dirSal = dirDes;
    }

    this.sentidoSalida = dirSal;
    this.nivel = nivel;

    let texto: string;
    if (dirDes === 0 && nivel <= 0) texto = "Parado";
    else if (dirDes === 0) texto = "Parando";
    else if (dirDes !== dirSal) texto = "Cambiando de sentido";
    else if (dirSal === 1) texto = "Girando a la derecha";
    else texto = "Girando a la izquierda";

    this.snapshot = this.buildSnapshot(texto);
    this.emit();
  }

  private buildSnapshot(estado: string): EngineSnapshot {
    return {
      sentido: this.sentido,
      sentidoSalida: this.sentidoSalida,
      nivel: this.nivel,
      estado,
      timerLeftMs:
        this.timerUntil !== null ? Math.max(0, this.timerUntil - performance.now()) : null,
      activo: this.nivel > 0 || this.sentido !== 0,
    };
  }

  private emit() {
    for (const fn of this.listeners) fn(this.snapshot);
  }
}
