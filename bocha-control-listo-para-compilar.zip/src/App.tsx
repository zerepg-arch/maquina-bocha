import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { ConnectSheet } from "./components/ConnectSheet";
import { Controls } from "./components/Controls";
import { Gauge } from "./components/Gauge";
import { Header } from "./components/Header";
import { SettingsPanel } from "./components/SettingsPanel";
import { useBocha } from "./lib/useBocha";

function Splash() {
  return (
    <motion.div
      exit={{ opacity: 0, transition: { duration: 0.45 } }}
      className="fixed inset-0 z-[60] flex flex-col items-center justify-center bg-void"
    >
      <div className="flex items-baseline">
        {"BOCHA".split("").map((c, i) => (
          <motion.span
            key={i}
            initial={{ opacity: 0, y: 16, letterSpacing: "0.5em" }}
            animate={{ opacity: 1, y: 0, letterSpacing: "0.1em" }}
            transition={{ delay: 0.12 + i * 0.07, type: "spring", stiffness: 210, damping: 22 }}
            className="font-display text-[54px] leading-none text-ink"
          >
            {c}
          </motion.span>
        ))}
        <motion.span
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.55, type: "spring", stiffness: 300, damping: 14 }}
          className="font-display text-[54px] leading-none text-ember"
        >
          .
        </motion.span>
      </div>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6, duration: 0.4 }}
        className="mt-3 font-mono text-[9px] tracking-[0.5em] text-dim uppercase"
      >
        Motor control · ESPHome
      </motion.p>
      <motion.div
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ delay: 0.3, duration: 1.15, ease: [0.2, 0.8, 0.2, 1] }}
        className="absolute bottom-0 left-0 h-[2px] w-full origin-left bg-gradient-to-r from-transparent via-ember to-transparent"
      />
    </motion.div>
  );
}

export default function App() {
  const bocha = useBocha();
  const [booted, setBooted] = useState(false);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [installEvt, setInstallEvt] = useState<{ prompt: () => Promise<void> } | null>(null);

  useEffect(() => {
    const t = setTimeout(() => setBooted(true), 1650);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setInstallEvt(e as unknown as { prompt: () => Promise<void> });
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  return (
    <div className="relative min-h-dvh bg-void text-ink">
      {/* fondo */}
      <div className="bg-grid pointer-events-none fixed inset-0" />
      <div className="noise pointer-events-none fixed inset-0" />
      <div
        className="pointer-events-none fixed inset-0"
        style={{ background: "radial-gradient(ellipse 90% 60% at 50% -10%, rgba(255,178,36,0.07), transparent 60%)" }}
      />
      <div
        className="pointer-events-none fixed inset-0"
        style={{ background: "radial-gradient(ellipse 140% 100% at 50% 115%, rgba(7,8,11,0.9), transparent 55%)" }}
      />

      <AnimatePresence>{!booted && <Splash />}</AnimatePresence>

      <div className="pt-safe pb-safe relative mx-auto flex min-h-dvh w-full max-w-[440px] flex-col px-5">
        <Header link={bocha.link} host={bocha.host} onOpenConnect={() => setSheetOpen(true)} />

        <motion.main
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: booted ? 1 : 0, y: booted ? 0 : 18 }}
          transition={{ duration: 0.7, ease: [0.2, 0.8, 0.2, 1], delay: 0.1 }}
          className="mt-6 flex flex-1 flex-col"
        >
          <Gauge snap={bocha.snap} estado={bocha.estadoShown} />

          <div className="mt-5">
            <Controls
              sentido={bocha.snap.sentido}
              sentidoSalida={bocha.snap.sentidoSalida}
              link={bocha.link}
              onLeft={() => bocha.giro(-1)}
              onRight={() => bocha.giro(1)}
              onStop={bocha.parar}
            />
          </div>

          <SettingsPanel cfg={bocha.cfg} onChange={(k, v) => bocha.setParam(k, v)} />

          <footer className="mt-10 mb-2">
            <div className="mb-4 h-px w-full bg-edge" />
            <div className="flex flex-col gap-1.5 font-mono text-[9px] tracking-[0.22em] text-dim uppercase">
              <div className="flex justify-between">
                <span>maquina-bocha · d1 mini</span>
                <span>web_server v3</span>
              </div>
              <div className="flex justify-between">
                <span>gpio5 → derecha · gpio4 → izquierda</span>
                <span className="tabular">{bocha.host}</span>
              </div>
            </div>
          </footer>
        </motion.main>
      </div>

      <ConnectSheet
        open={sheetOpen}
        onClose={() => setSheetOpen(false)}
        host={bocha.host}
        link={bocha.link}
        onSetHost={bocha.setHost}
        onProbe={bocha.probe}
        onSync={bocha.syncFromDevice}
        canInstall={installEvt !== null}
        onInstallPwa={() => {
          void installEvt?.prompt();
          setInstallEvt(null);
        }}
      />
    </div>
  );
}
