import { motion } from "framer-motion";
import { OctagonX, RotateCcw, RotateCw } from "lucide-react";
import type { Link } from "../lib/esphome";

interface Props {
  sentido: number;
  sentidoSalida: number;
  link: Link;
  onLeft: () => void;
  onRight: () => void;
  onStop: () => void;
}

function DirButton({
  side,
  active,
  onPress,
}: {
  side: "left" | "right";
  active: boolean;
  onPress: () => void;
}) {
  const Icon = side === "left" ? RotateCcw : RotateCw;
  const label = side === "left" ? "IZQUIERDA" : "DERECHA";
  return (
    <motion.button
      whileTap={{ scale: 0.92 }}
      onClick={onPress}
      className={`group relative flex h-24 flex-col items-center justify-center gap-1.5 overflow-hidden rounded-3xl border transition-colors duration-300 ${
        active
          ? "border-ember/60 bg-gradient-to-b from-ember/25 to-ember/5 shadow-[inset_0_0_30px_rgba(255,178,36,0.08)]"
          : "border-edge bg-panel active:border-ember/40"
      }`}
    >
      {active && (
        <span className="absolute top-2.5 h-1.5 w-1.5 rounded-full bg-ember shadow-[0_0_8px_rgba(255,178,36,0.9)]" />
      )}
      <Icon
        size={30}
        strokeWidth={2.2}
        className={`transition-colors duration-300 ${active ? "text-ember" : "text-mute group-active:text-ink"}`}
      />
      <span
        className={`font-mono text-[10px] tracking-[0.3em] transition-colors duration-300 ${
          active ? "text-emberhi" : "text-dim"
        }`}
      >
        {label}
      </span>
    </motion.button>
  );
}

export function Controls({ sentido, sentidoSalida, link, onLeft, onRight, onStop }: Props) {
  return (
    <div>
      <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3">
        <DirButton side="left" active={sentidoSalida === -1} onPress={onLeft} />

        <motion.button
          whileTap={{ scale: 0.88 }}
          onClick={onStop}
          aria-label="Parar"
          className={`flex h-[86px] w-[86px] flex-col items-center justify-center gap-1 rounded-full border-2 transition-all duration-200 ${
            sentido === 0 && sentidoSalida === 0
              ? "border-edge bg-panel"
              : "border-stopx/60 bg-stopx/10 shadow-[0_0_26px_rgba(255,77,85,0.22)]"
          } active:bg-stopx/25`}
        >
          <OctagonX
            size={30}
            strokeWidth={2.2}
            className={sentido === 0 && sentidoSalida === 0 ? "text-dim" : "text-stopx"}
          />
          <span className="font-mono text-[9px] tracking-[0.26em] text-mute">PARAR</span>
        </motion.button>

        <DirButton side="right" active={sentidoSalida === 1} onPress={onRight} />
      </div>

      {link === "offline" && (
        <p className="mt-3 text-center font-mono text-[10px] tracking-[0.18em] text-stopx/80 uppercase">
          Sin conexión — reintentando en segundo plano
        </p>
      )}
      {link === "opaque" && (
        <p className="mt-3 text-center font-mono text-[10px] tracking-[0.18em] text-mute uppercase">
          Control a ciegas · estado simulado localmente
        </p>
      )}
    </div>
  );
}
