import { motion } from "framer-motion";
import { Gauge as GaugeIcon, Minus, Plus, Timer, TrendingDown, TrendingUp } from "lucide-react";
import type { EngineConfig } from "../lib/engine";

interface Props {
  cfg: EngineConfig;
  onChange: (key: keyof EngineConfig, value: number) => void;
}

function Chip({ label, onClick, active }: { label: string; onClick: () => void; active: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-3 py-1 font-mono text-[10px] tracking-[0.12em] transition-colors ${
        active
          ? "border-ember/60 bg-ember/15 text-emberhi"
          : "border-edge bg-transparent text-mute active:border-ember/40 active:text-ink"
      }`}
    >
      {label}
    </button>
  );
}

function Card({
  icon,
  title,
  desc,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  desc: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-edge bg-panel p-4">
      <div className="mb-3 flex items-start gap-2.5">
        <span className="mt-0.5 text-emberdim">{icon}</span>
        <div>
          <h3 className="font-mono text-[11px] font-medium tracking-[0.22em] text-ink uppercase">{title}</h3>
          <p className="mt-0.5 text-[11px] leading-snug text-dim">{desc}</p>
        </div>
      </div>
      {children}
    </div>
  );
}

function Stepper({
  value,
  min,
  max,
  step,
  unit,
  onChange,
  render,
}: {
  value: number;
  min: number;
  max: number;
  step: number;
  unit: string;
  onChange: (v: number) => void;
  render?: (v: number) => string;
}) {
  const clamp = (v: number) => Math.min(max, Math.max(min, Math.round(v * 2) / 2));
  const shown = render ? render(value) : `${value % 1 !== 0 ? value.toFixed(1) : value} ${unit}`;
  return (
    <div className="flex items-center justify-between rounded-xl border border-edge bg-panel2 px-2 py-1.5">
      <motion.button
        whileTap={{ scale: 0.85 }}
        onClick={() => onChange(clamp(value - step))}
        className="flex h-9 w-9 items-center justify-center rounded-lg border border-edge text-mute active:border-ember/50 active:text-ember"
        aria-label="Menos"
      >
        <Minus size={16} />
      </motion.button>
      <span className="tabular font-mono text-lg text-ink">{shown}</span>
      <motion.button
        whileTap={{ scale: 0.85 }}
        onClick={() => onChange(clamp(value + step))}
        className="flex h-9 w-9 items-center justify-center rounded-lg border border-edge text-mute active:border-ember/50 active:text-ember"
        aria-label="Más"
      >
        <Plus size={16} />
      </motion.button>
    </div>
  );
}

export function SettingsPanel({ cfg, onChange }: Props) {
  const sliderPct = ((cfg.velocidad - 10) / 90) * 100;
  return (
    <section className="mt-9">
      <div className="mb-4 flex items-center gap-3">
        <span className="font-mono text-[10px] tracking-[0.4em] text-dim uppercase">Parámetros del motor</span>
        <span className="h-px flex-1 bg-edge" />
      </div>

      <div className="flex flex-col gap-3">
        <Card
          icon={<GaugeIcon size={15} />}
          title="Velocidad"
          desc="Potencia PWM del motor en GPIO4/GPIO5 · 10–100 %"
        >
          <div className="mb-1.5 flex items-baseline justify-between">
            <span className="tabular font-display text-3xl text-emberhi">{cfg.velocidad}%</span>
            <span className="font-mono text-[10px] tracking-widest text-dim">SLIDER</span>
          </div>
          <input
            type="range"
            min={10}
            max={100}
            step={5}
            value={cfg.velocidad}
            onChange={(e) => onChange("velocidad", Number(e.target.value))}
            className="slider"
            style={{
              background: `linear-gradient(90deg, #ffb224 ${sliderPct}%, #161b23 ${sliderPct}%)`,
            }}
            aria-label="Velocidad"
          />
          <div className="mt-3 flex gap-2">
            {[25, 50, 75, 100].map((v) => (
              <Chip key={v} label={`${v}%`} active={cfg.velocidad === v} onClick={() => onChange("velocidad", v)} />
            ))}
          </div>
        </Card>

        <Card
          icon={<Timer size={15} />}
          title="Temporizador"
          desc="Auto-parada del giro · 0 = sin límite"
        >
          <Stepper
            value={cfg.temporizador}
            min={0}
            max={180}
            step={0.5}
            unit="min"
            onChange={(v) => onChange("temporizador", v)}
            render={(v) => (v === 0 ? "sin límite" : `${v % 1 !== 0 ? v.toFixed(1) : v} min`)}
          />
          <div className="mt-3 flex flex-wrap gap-2">
            {[0, 1, 5, 10, 30].map((v) => (
              <Chip
                key={v}
                label={v === 0 ? "∞" : `${v} min`}
                active={cfg.temporizador === v}
                onClick={() => onChange("temporizador", v)}
              />
            ))}
          </div>
        </Card>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Card
            icon={<TrendingUp size={15} />}
            title="Rampa de aceleración"
            desc="0 = sin rampa · segundos"
          >
            <Stepper
              value={cfg.rampaSubida}
              min={0}
              max={20}
              step={0.5}
              unit="s"
              onChange={(v) => onChange("rampaSubida", v)}
              render={(v) => (v === 0 ? "off" : `${v % 1 !== 0 ? v.toFixed(1) : v} s`)}
            />
            <div className="mt-3 flex flex-wrap gap-2">
              {[0, 1, 2, 5].map((v) => (
                <Chip key={v} label={v === 0 ? "off" : `${v}s`} active={cfg.rampaSubida === v} onClick={() => onChange("rampaSubida", v)} />
              ))}
            </div>
          </Card>

          <Card
            icon={<TrendingDown size={15} />}
            title="Rampa de desaceleración"
            desc="0 = sin rampa · segundos"
          >
            <Stepper
              value={cfg.rampaBajada}
              min={0}
              max={20}
              step={0.5}
              unit="s"
              onChange={(v) => onChange("rampaBajada", v)}
              render={(v) => (v === 0 ? "off" : `${v % 1 !== 0 ? v.toFixed(1) : v} s`)}
            />
            <div className="mt-3 flex flex-wrap gap-2">
              {[0, 0.5, 1, 2].map((v) => (
                <Chip key={v} label={v === 0 ? "off" : `${v}s`} active={cfg.rampaBajada === v} onClick={() => onChange("rampaBajada", v)} />
              ))}
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
}
