import { Settings2 } from "lucide-react";
import type { Link } from "../lib/esphome";

const LINK_META: Record<Link, { dot: string; label: string; pulse?: boolean }> = {
  probing: { dot: "bg-ember", label: "CONECTANDO", pulse: true },
  full: { dot: "bg-okx", label: "EN LÍNEA" },
  opaque: { dot: "bg-ember", label: "A CIEGAS" },
  offline: { dot: "bg-stopx", label: "SIN CONEXIÓN" },
};

export function Header({ link, host, onOpenConnect }: { link: Link; host: string; onOpenConnect: () => void }) {
  const meta = LINK_META[link];
  return (
    <header className="flex items-center justify-between">
      <div>
        <h1 className="font-display text-[28px] leading-none tracking-[0.08em] text-ink">
          BOCHA<span className="text-ember">.</span>
        </h1>
        <p className="mt-1 font-mono text-[9px] tracking-[0.42em] text-dim uppercase">Motor control · ESP8266</p>
      </div>

      <button
        onClick={onOpenConnect}
        className="flex items-center gap-2.5 rounded-full border border-edge bg-panel py-2 pr-3 pl-2.5 active:border-ember/50"
      >
        <span className={`relative flex h-2 w-2`}>
          {meta.pulse && (
            <span className={`absolute inline-flex h-full w-full animate-ping rounded-full ${meta.dot} opacity-60`} />
          )}
          <span className={`relative inline-flex h-2 w-2 rounded-full ${meta.dot}`} />
        </span>
        <span className="font-mono text-[9px] tracking-[0.2em] text-mute">{meta.label}</span>
        <span className="max-w-[86px] truncate font-mono text-[9px] text-dim">{host}</span>
        <Settings2 size={13} className="text-dim" />
      </button>
    </header>
  );
}
