import { ChevronsLeft, ChevronsRight, Timer } from "lucide-react";
import type { EngineSnapshot } from "../lib/engine";

const CX = 160;
const CY = 160;
const A0 = -120;
const SWEEP = 240;

const polar = (r: number, angleDeg: number): [number, number] => {
  const a = (angleDeg * Math.PI) / 180; // 0 = arriba, sentido horario
  return [CX + r * Math.sin(a), CY - r * Math.cos(a)];
};

const arcPath = (r: number, a0: number, a1: number): string => {
  const [x0, y0] = polar(r, a0);
  const [x1, y1] = polar(r, a1);
  const large = a1 - a0 > 180 ? 1 : 0;
  return `M ${x0.toFixed(2)} ${y0.toFixed(2)} A ${r} ${r} 0 ${large} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
};

const fmtTimer = (ms: number) => {
  const s = Math.ceil(ms / 1000);
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
};

function estadoColor(estado: string): string {
  if (estado === "Parado") return "text-dim";
  if (estado === "Parando") return "text-mute";
  if (estado === "Cambiando de sentido") return "text-ember blink-soft";
  return "text-emberhi";
}

export function Gauge({ snap, estado }: { snap: EngineSnapshot; estado: string }) {
  const { nivel, sentidoSalida, timerLeftMs, sentido, activo } = snap;
  const pct = Math.round(nivel * 100);
  const needleAngle = A0 + nivel * SWEEP;
  const timerOn = timerLeftMs !== null && sentido !== 0;

  const ticks = Array.from({ length: 49 }, (_, i) => {
    const frac = i / 48;
    const ang = A0 + frac * SWEEP;
    const major = i % 4 === 0;
    const len = major ? 15 : 8;
    const [x0, y0] = polar(146, ang);
    const [x1, y1] = polar(146 - len, ang);
    const lit = frac <= nivel + 1e-4;
    return (
      <line
        key={i}
        x1={x0}
        y1={y0}
        x2={x1}
        y2={y1}
        stroke={lit ? (major ? "#ffce6b" : "#ffb224") : "#1b212b"}
        strokeWidth={major ? 3 : 2}
        strokeLinecap="round"
        opacity={lit ? 1 : 0.9}
      />
    );
  });

  return (
    <div className="relative mx-auto w-full max-w-[350px]">
      {/* halo trasero que respira con el nivel */}
      <div
        className="pointer-events-none absolute inset-[-28%] transition-opacity duration-700"
        style={{
          background: `radial-gradient(circle at 50% 46%, rgba(255,178,36,${(0.05 + nivel * 0.22).toFixed(3)}) 0%, rgba(255,178,36,${(nivel * 0.07).toFixed(3)}) 34%, transparent 62%)`,
          opacity: activo ? 1 : 0.7,
        }}
      />

      <svg viewBox="0 0 320 320" className="relative block w-full">
        <defs>
          <filter id="glow" x="-60%" y="-60%" width="220%" height="220%">
            <feGaussianBlur stdDeviation="5" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <linearGradient id="arcgrad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#ff9d2e" />
            <stop offset="100%" stopColor="#ffd06e" />
          </linearGradient>
        </defs>

        {/* anillo decorativo exterior */}
        <circle cx={CX} cy={CY} r={154} fill="none" stroke="#161c25" strokeWidth="1" strokeDasharray="2 7" />
        {ticks}

        {/* pista */}
        <path d={arcPath(112, A0, A0 + SWEEP)} fill="none" stroke="#151a22" strokeWidth="8" strokeLinecap="round" />

        {/* progreso */}
        {nivel > 0.002 && (
          <>
            <path
              d={arcPath(112, A0, A0 + nivel * SWEEP)}
              fill="none"
              stroke="#ffb224"
              strokeWidth="15"
              strokeLinecap="round"
              opacity="0.22"
              filter="url(#glow)"
            />
            <path
              d={arcPath(112, A0, nivel * SWEEP < 2 ? A0 + 2 : A0 + nivel * SWEEP)}
              fill="none"
              stroke="url(#arcgrad)"
              strokeWidth="8"
              strokeLinecap="round"
            />
          </>
        )}

        {/* aguja */}
        <g
          style={{
            transform: `rotate(${needleAngle}deg)`,
            transformOrigin: "160px 160px",
            transition: "transform 0.16s cubic-bezier(.25,.9,.3,1.15)",
          }}
        >
          <line x1={CX} y1={CY + 14} x2={CX} y2={CY} stroke="#39424f" strokeWidth="5" strokeLinecap="round" />
          <line x1={CX} y1={CY} x2={CX} y2={52} stroke="#eef2f7" strokeWidth="3.5" strokeLinecap="round" />
          <circle cx={CX} cy={52} r="4.5" fill="#ffb224" filter="url(#glow)" />
        </g>
        <circle cx={CX} cy={CY} r="15" fill="#0c0e12" stroke="#2b3441" strokeWidth="2" />
        <circle cx={CX} cy={CY} r="4.5" fill={activo ? "#ffb224" : "#39424f"} />
      </svg>

      {/* anillo giratorio de dirección */}
      {activo && (
        <div
          className="spin-slow pointer-events-none absolute inset-[15%] rounded-full border border-dashed border-ember/25"
          style={{ animationDuration: `${Math.max(2.2, 9 - nivel * 7)}s` }}
        />
      )}

      {/* chevrones de dirección */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-between px-1">
        <ChevronsLeft
          size={34}
          strokeWidth={2.4}
          className={
            sentidoSalida === -1 ? "text-ember drop-shadow-[0_0_10px_rgba(255,178,36,.7)]" : "text-edge"
          }
        />
        <ChevronsRight
          size={34}
          strokeWidth={2.4}
          className={
            sentidoSalida === 1 ? "text-ember drop-shadow-[0_0_10px_rgba(255,178,36,.7)]" : "text-edge"
          }
        />
      </div>

      {/* lecturas centrales */}
      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-1 pt-2">
        <span className="font-mono text-[9px] tracking-[0.34em] text-dim uppercase">Estado</span>
        <span className={`font-mono text-[11px] tracking-[0.2em] uppercase ${estadoColor(estado)}`}>
          {estado}
        </span>
        <div className="mt-1 flex items-baseline gap-1">
          <span className="font-display tabular text-[64px] leading-none text-ink">{pct}</span>
          <span className="font-mono text-lg text-dim">%</span>
        </div>
        {timerOn && (
          <div className="mt-1 flex items-center gap-1.5 rounded-full border border-ember/30 bg-ember/10 px-2.5 py-1">
            <Timer size={11} className="text-ember" />
            <span className="font-mono text-[10px] tracking-[0.14em] text-emberhi">
              AUTO-PARADA {fmtTimer(timerLeftMs!)}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
