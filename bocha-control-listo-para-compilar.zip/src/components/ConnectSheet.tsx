import { AnimatePresence, motion } from "framer-motion";
import {
  Check,
  Download,
  Loader2,
  MonitorSmartphone,
  RefreshCw,
  Wifi,
  WifiOff,
  X,
} from "lucide-react";
import { useEffect, useState } from "react";
import type { Link } from "../lib/esphome";

interface Props {
  open: boolean;
  onClose: () => void;
  host: string;
  link: Link;
  onSetHost: (h: string) => void;
  onProbe: () => Promise<Link>;
  onSync: () => Promise<void>;
  canInstall: boolean;
  onInstallPwa: () => void;
}

const isFileRuntime = typeof location !== "undefined" && location.protocol === "file:";
const isStandalone =
  typeof window !== "undefined" &&
  (window.matchMedia?.("(display-mode: standalone)").matches ||
    (navigator as unknown as { standalone?: boolean }).standalone === true);

function ProbeResult({ link, latency }: { link: Link | null; latency: number | null }) {
  if (!link) return null;
  const ms = latency !== null ? ` · ${latency} ms` : "";
  if (link === "full")
    return (
      <p className="flex items-center gap-1.5 font-mono text-[10px] tracking-[0.14em] text-okx">
        <Check size={12} /> ENLACE COMPLETO — lectura y control{ms}
      </p>
    );
  if (link === "opaque")
    return (
      <p className="flex items-center gap-1.5 font-mono text-[10px] tracking-[0.14em] text-ember">
        <Check size={12} /> SOLO CONTROL — la máquina no expone lectura a este origen{ms}
      </p>
    );
  return (
    <p className="flex items-center gap-1.5 font-mono text-[10px] tracking-[0.14em] text-stopx">
      <WifiOff size={12} /> NO RESPONDE — revisa IP o red
    </p>
  );
}

export function ConnectSheet({
  open,
  onClose,
  host,
  link,
  onSetHost,
  onProbe,
  onSync,
  canInstall,
  onInstallPwa,
}: Props) {
  const [value, setValue] = useState(host);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Link | null>(null);
  const [latency, setLatency] = useState<number | null>(null);

  useEffect(() => {
    if (open) {
      setValue(host);
      setResult(null);
    }
  }, [open, host]);

  const saveAndProbe = async (h: string) => {
    setBusy(true);
    const t0 = performance.now();
    onSetHost(h);
    const linkRes = await onProbe();
    setLatency(Math.round(performance.now() - t0));
    setResult(linkRes);
    setBusy(false);
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm"
          />
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 320, damping: 34 }}
            className="pb-safe fixed inset-x-0 bottom-0 z-50 mx-auto max-h-[86dvh] w-full max-w-[440px] overflow-y-auto rounded-t-3xl border-t border-edge bg-coal px-5 pt-3"
          >
            <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-edge" />

            <div className="mb-5 flex items-center justify-between">
              <h2 className="font-mono text-[12px] tracking-[0.3em] text-ink uppercase">Conexión con la máquina</h2>
              <button
                onClick={onClose}
                className="flex h-8 w-8 items-center justify-center rounded-full border border-edge text-mute active:text-ink"
                aria-label="Cerrar"
              >
                <X size={15} />
              </button>
            </div>

            <label className="mb-1.5 block font-mono text-[9px] tracking-[0.3em] text-dim uppercase">
              IP o nombre del ESP8266
            </label>
            <div className="flex gap-2">
              <input
                value={value}
                onChange={(e) => setValue(e.target.value)}
                spellCheck={false}
                autoCapitalize="off"
                autoCorrect="off"
                inputMode="url"
                placeholder="192.168.4.1"
                className="tabular min-w-0 flex-1 rounded-xl border border-edge bg-panel px-3.5 py-3 font-mono text-sm text-ink outline-none placeholder:text-dim focus:border-ember/60"
              />
              <motion.button
                whileTap={{ scale: 0.94 }}
                disabled={busy}
                onClick={() => void saveAndProbe(value)}
                className="flex items-center gap-2 rounded-xl bg-ember px-4 font-mono text-[11px] font-medium tracking-[0.12em] text-black disabled:opacity-50"
              >
                {busy ? <Loader2 size={14} className="animate-spin" /> : <Wifi size={14} />}
                PROBAR
              </motion.button>
            </div>

            <div className="mt-2.5 flex flex-wrap gap-2">
              {[
                { label: "192.168.4.1 · AP «Maquina Bocha»", v: "192.168.4.1" },
                { label: "maquina-bocha.local", v: "maquina-bocha.local" },
              ].map((c) => (
                <button
                  key={c.v}
                  onClick={() => {
                    setValue(c.v);
                    void saveAndProbe(c.v);
                  }}
                  className="rounded-full border border-edge px-3 py-1.5 font-mono text-[10px] text-mute active:border-ember/50 active:text-ink"
                >
                  {c.label}
                </button>
              ))}
            </div>

            <div className="mt-3 min-h-4">
              <ProbeResult link={result ?? link} latency={result ? latency : null} />
            </div>

            {link === "full" && (
              <button
                onClick={() => void onSync()}
                className="mt-1 flex items-center gap-2 font-mono text-[10px] tracking-[0.16em] text-mute uppercase active:text-ember"
              >
                <RefreshCw size={12} /> Sincronizar parámetros desde el dispositivo
              </button>
            )}

            <div className="mt-4 rounded-xl border border-edge bg-panel p-3.5">
              <p className="text-[11px] leading-relaxed text-mute">
                <span className="text-ink">El botón PARAR es inmediato y resetea el control.</span>{" "}
                Si el teléfono está en la red del dispositivo (<span className="font-mono">Maquina Bocha</span>,
                sin internet), la app instalada funciona igualmente offline. En el WiFi de casa usa la IP que le
                asigne tu router (resérvala en el DHCP para que no cambie).
              </p>
            </div>

            <div className="mt-6 mb-2 flex items-center gap-3">
              <span className="h-px w-6 bg-edge" />
              <span className="font-mono text-[10px] tracking-[0.4em] text-dim uppercase">Instalar en Android</span>
              <span className="h-px flex-1 bg-edge" />
            </div>

            {isFileRuntime ? (
              <div className="flex items-start gap-3 rounded-xl border border-okx/25 bg-okx/5 p-3.5">
                <Check size={16} className="mt-0.5 shrink-0 text-okx" />
                <p className="text-[11px] leading-relaxed text-mute">
                  Ya estás usando el <span className="text-ink">APK instalado</span>. Toda la app vive dentro del
                  paquete: funciona sin internet y habla directo con el ESP8266.
                </p>
              </div>
            ) : (
              <div className="flex flex-col gap-2.5">
                <motion.a
                  whileTap={{ scale: 0.97 }}
                  href="/bocha-control.apk"
                  download="bocha-control.apk"
                  className="flex items-center gap-3 rounded-2xl border border-ember/40 bg-gradient-to-b from-ember/20 to-ember/5 p-4"
                >
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-ember text-black">
                    <Download size={20} />
                  </span>
                  <span className="flex-1">
                    <span className="block font-mono text-[12px] tracking-[0.14em] text-ink uppercase">
                      Descargar APK
                    </span>
                    <span className="mt-0.5 block text-[11px] text-mute">
                      Instalador nativo · sin CORS ni internet · la opción recomendada
                    </span>
                  </span>
                </motion.a>

                <motion.button
                  whileTap={{ scale: 0.97 }}
                  onClick={onInstallPwa}
                  className="flex items-center gap-3 rounded-2xl border border-edge bg-panel p-4"
                >
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-edge text-ember">
                    <MonitorSmartphone size={20} />
                  </span>
                  <span className="flex-1 text-left">
                    <span className="block font-mono text-[12px] tracking-[0.14em] text-ink uppercase">
                      {isStandalone ? "App web instalada" : canInstall ? "Instalar como PWA" : "Instalar como PWA"}
                    </span>
                    <span className="mt-0.5 block text-[11px] text-mute">
                      {isStandalone
                        ? "Ya se ejecuta a pantalla completa."
                        : canInstall
                          ? "Un toque — aparece el diálogo de Chrome."
                          : "En Chrome: menú ⋮ → «Instalar aplicación»."}
                    </span>
                  </span>
                </motion.button>

                <p className="px-1 text-[10.5px] leading-relaxed text-dim">
                  ¿Quieres firmar/regenerar el APK tú mismo? Sube esta URL a{" "}
                  <span className="font-mono text-mute">pwabuilder.com</span> y descarga el paquete Android, o usa{" "}
                  <span className="font-mono text-mute">npx @bubblewrap/cli init</span>.
                </p>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
